title: 阿贾克斯的 Bolo 博客系统已部署成功。
date: '2020-09-02 21:55:00'
updated: '2020-09-02 22:08:03'
tags: [Bolo]
permalink: /hello-bolo
---
![](https://b3logfile.com/bing/20180524.jpg?imageView2/1/w/1280/h/720/interlace/1/q/100)

Bolo 博客系统已经初始化完毕，可在管理后台 - 工具 - 偏好设定中调整更多细节设置。如果需要导入已有博客文章，请参考文档 [Hexo/Jekyll/Markdown 文件导入](https://hacpai.com/article/1498490209748)。

Bolo 是基于 [Solo](https://github.com/b3log/solo) 的修改版，主打功能：

1. 离线
2. 分类优化
3. 游客化评论
4. 同步与主分支更新

欢迎你的体验！

请在设置-偏好设定中设置黑客派用户名和 B3log Key 以获得完整体验。

最后，如果你觉得 Bolo 很赞，请到[项目主页](https://github.com/adlered/bolo-solo)给颗星鼓励一下 :heart:

